# 🤠 Pistolero del Oeste (Android)

Juego de zombis en primera persona hecho con Three.js, empaquetado como app Android (WebView).
El juego vive en `app/src/main/assets/index.html`.

## Bajar el APK desde GitHub
1. Subí este proyecto a un repositorio (rama `main`).
2. Entrá a **Actions → Compilar APK** y esperá a que termine.
3. Descargá `pistolero-del-oeste-apk` desde **Artifacts** y pasalo al celular.
4. Instalalo (hay que permitir "instalar apps desconocidas").

### Release automático
```bash
git tag v1.0
git push origin v1.0
```
El APK queda adjunto en **Releases**.

## Compilar en local
Con Android Studio: abrí la carpeta y **Build → Build APK(s)**.
Con consola (Gradle 8.7+, JDK 17 y Android SDK): `gradle assembleDebug`.

## Editar el juego
Cambiá `app/src/main/assets/index.html` y volvé a compilar.

## Controles
Joystick para moverte, deslizar para apuntar, tocar para disparar y 🛡️ para esconderte.
En PC (abriendo el HTML): WASD, C, R y Espacio.

> El APK sale firmado con la clave de debug: sirve para instalar y probar, pero no para Play Store.
